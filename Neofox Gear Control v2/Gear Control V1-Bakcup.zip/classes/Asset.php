<?php
// classes/Asset.php
class Asset {
    private $conn;
    private $table_name = "assets";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (asset_id, asset_name, category, description, serial_number, qr_code, condition_status, notes) 
                  VALUES (:asset_id, :asset_name, :category, :description, :serial_number, :qr_code, :condition_status, :notes)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":asset_id", $data['asset_id']);
        $stmt->bindParam(":asset_name", $data['asset_name']);
        $stmt->bindParam(":category", $data['category']);
        $stmt->bindParam(":description", $data['description']);
        $stmt->bindParam(":serial_number", $data['serial_number']);
        $stmt->bindParam(":qr_code", $data['qr_code']);
        $stmt->bindParam(":condition_status", $data['condition_status']);
        $stmt->bindParam(":notes", $data['notes']);
        
        return $stmt->execute();
    }

    public function getAll() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY asset_name";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getByAssetId($asset_id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE asset_id = :asset_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":asset_id", $asset_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function checkOut($asset_id, $borrower, $expected_return, $purpose) {
        $query = "UPDATE " . $this->table_name . " 
                  SET status = 'checked_out', current_borrower = :borrower, 
                      checkout_date = NOW(), expected_return_date = :expected_return 
                  WHERE asset_id = :asset_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":asset_id", $asset_id);
        $stmt->bindParam(":borrower", $borrower);
        $stmt->bindParam(":expected_return", $expected_return);
        
        if ($stmt->execute()) {
            $this->logTransaction($asset_id, $borrower, 'checkout', $purpose);
            return true;
        }
        return false;
    }

    public function checkIn($asset_id, $condition, $notes) {
        // Get borrower before clearing
        $asset = $this->getByAssetId($asset_id);
        $borrower = $asset['current_borrower'];
        
        $query = "UPDATE " . $this->table_name . " 
                  SET status = 'available', current_borrower = NULL, 
                      checkout_date = NULL, expected_return_date = NULL, 
                      condition_status = :condition 
                  WHERE asset_id = :asset_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":asset_id", $asset_id);
        $stmt->bindParam(":condition", $condition);
        
        if ($stmt->execute()) {
            $this->logTransaction($asset_id, $borrower, 'checkin', $notes, $condition);
            return true;
        }
        return false;
    }

    private function logTransaction($asset_id, $borrower, $type, $notes, $condition = null) {
        $query = "INSERT INTO transactions (asset_id, borrower_name, transaction_type, purpose, condition_on_return, notes) 
                  VALUES (:asset_id, :borrower, :type, :purpose, :condition, :notes)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":asset_id", $asset_id);
        $stmt->bindParam(":borrower", $borrower);
        $stmt->bindParam(":type", $type);
        $stmt->bindParam(":purpose", $notes);
        $stmt->bindParam(":condition", $condition);
        $stmt->bindParam(":notes", $notes);
        $stmt->execute();
    }

    public function getOverdueAssets() {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE status = 'checked_out' AND expected_return_date < NOW()";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getCheckedOutAssets() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE status = 'checked_out'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAssetStats() {
        $query = "SELECT 
                    COUNT(*) as total_assets,
                    SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available,
                    SUM(CASE WHEN status = 'checked_out' THEN 1 ELSE 0 END) as checked_out,
                    SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END) as maintenance,
                    SUM(CASE WHEN status = 'lost' THEN 1 ELSE 0 END) as lost
                  FROM " . $this->table_name;
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

// classes/GearRequest.php
class GearRequest {
    private $conn;
    private $table_name = "gear_requests";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (requester_name, requester_email, required_items, request_dates, purpose) 
                  VALUES (:name, :email, :items, :dates, :purpose)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":name", $data['requester_name']);
        $stmt->bindParam(":email", $data['requester_email']);
        $stmt->bindParam(":items", $data['required_items']);
        $stmt->bindParam(":dates", $data['request_dates']);
        $stmt->bindParam(":purpose", $data['purpose']);
        
        return $stmt->execute();
    }

    public function getAll() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateStatus($id, $status, $admin_notes = '') {
        $query = "UPDATE " . $this->table_name . " 
                  SET status = :status, admin_notes = :notes 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":notes", $admin_notes);
        
        return $stmt->execute();
    }
}

// classes/QRGenerator.php
class QRGenerator2 {
    public static function generateQRCode($text, $size = 200) {
        // Using Google Charts API for QR generation
        $url = "https://chart.googleapis.com/chart?chs={$size}x{$size}&cht=qr&chl=" . urlencode($text);
        return $url;
    }

    public static function generateAssetQR($asset_id, $base_url) {
        $checkout_url = $base_url . "/checkout.php?asset_id=" . $asset_id;
        return self::generateQRCode($checkout_url);
    }
}

// classes/EmailNotification.php
class EmailNotification2 {
    public static function sendCheckoutConfirmation($to_email, $asset_name, $borrower, $return_date) {
        $subject = "Equipment Checked Out - {$asset_name}";
        $message = "
        <h3>Equipment Checkout Confirmation</h3>
        <p><strong>Asset:</strong> {$asset_name}</p>
        <p><strong>Borrower:</strong> {$borrower}</p>
        <p><strong>Expected Return:</strong> {$return_date}</p>
        <p>Please return the equipment on time and in good condition.</p>
        ";
        
        return self::sendEmail($to_email, $subject, $message);
    }

    public static function sendOverdueAlert($to_email, $asset_name, $borrower, $days_overdue) {
        $subject = "OVERDUE EQUIPMENT ALERT - {$asset_name}";
        $message = "
        <h3>Equipment Overdue Alert</h3>
        <p><strong>Asset:</strong> {$asset_name}</p>
        <p><strong>Borrower:</strong> {$borrower}</p>
        <p><strong>Days Overdue:</strong> {$days_overdue}</p>
        <p style='color: red;'><strong>This equipment needs to be returned immediately!</strong></p>
        ";
        
        return self::sendEmail($to_email, $subject, $message);
    }

    private static function sendEmail($to, $subject, $message) {
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: Neofox Gear Control <noreply@neofox.com>' . "\r\n";
        
        return mail($to, $subject, $message, $headers);
    }
}
?>
<?php
// gear_request.php - Gear Request Form
require_once 'config/database.php';
require_once 'classes/GearRequest.php';
require_once 'classes/EmailNotification.php';

$database = new Database();
$db = $database->getConnection();
$gear_request = new GearRequest($db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        'requester_name' => $_POST['requester_name'],
        'requester_email' => $_POST['requester_email'],
        'required_items' => $_POST['required_items'],
        'request_dates' => $_POST['request_dates'],
        'purpose' => $_POST['purpose']
    ];
    
    if ($gear_request->create($data)) {
        $success = "Gear request submitted successfully!";
        // Send notification to admin
        EmailNotification::sendEmail(
            'admin@neofox.com',
            'New Gear Request - ' . $data['requester_name'],
            "A new gear request has been submitted by " . $data['requester_name'] . " for " . $data['request_dates']
        );
    } else {
        $error = "Failed to submit gear request.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Gear - Neofox Gear Control</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h4><i class="fas fa-calendar-alt"></i> Request Equipment</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="requester_name" class="form-label">Your Name *</label>
                                        <input type="text" class="form-control" id="requester_name" name="requester_name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="requester_email" class="form-label">Your Email</label>
                                        <input type="email" class="form-control" id="requester_email" name="requester_email">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="required_items" class="form-label">Required Equipment *</label>
                                <textarea class="form-control" id="required_items" name="required_items" rows="4" 
                                    placeholder="List the equipment you need (cameras, lenses, audio gear, etc.)" required></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="request_dates" class="form-label">Requested Dates *</label>
                                <input type="text" class="form-control" id="request_dates" name="request_dates" 
                                    placeholder="e.g., March 15-17, 2024" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="purpose" class="form-label">Purpose / Project Details</label>
                                <textarea class="form-control" id="purpose" name="purpose" rows="3" 
                                    placeholder="Brief description of your project and how the equipment will be used"></textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-info w-100">
                                        <i class="fas fa-paper-plane"></i> Submit Request
                                    </button>
                                </div>
                                <div class="col-md-6">
                                    <a href="index.php" class="btn btn-secondary w-100">
                                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>